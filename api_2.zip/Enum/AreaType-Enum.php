<?php
abstract class AreaTypeEnum
{
    const Rial = 1;
    const Arz = 2;
    const Arz_Rial = 3;
}