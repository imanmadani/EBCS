<?php
abstract class GroupEnum
{
    const Admin = 1;
    const Executer = 2;
}