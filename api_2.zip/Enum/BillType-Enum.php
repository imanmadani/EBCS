<?php
abstract class BillTypeEnum
{
    const ExhibitionService = 1;
}