<?php
abstract class ResultEnum
{
    const Duplicate = 1;
}