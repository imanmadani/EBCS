<?php
abstract class IPGEnum
{
    const MerchantId = '000000140332034';
    const TerminalId = '24053263';
    const TerminalKey = 'rFKsMwwrRmj5qX530pCU8rlY3SlDUiOW';
}