<?php
abstract class QuantityTypeEnum
{
    const Number = 1;
    const Meter = 2;
}