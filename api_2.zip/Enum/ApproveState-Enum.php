<?php
abstract class ApproveStateEnum
{
    const None = "NULL";
    const  EndAction= 0;
    const  Approve= 1;
    const  DisApprove= 2;
}