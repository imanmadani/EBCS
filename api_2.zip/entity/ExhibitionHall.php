<?php
class ExhibitionHallClass
{
    public $Id;
    public $ExhibitionId;
    public $HallId;
}
?>