<?php
class Token
{
    public $Id;
    public $UserId;
    public $TokenCode;
    public $FlagValid;
    public $InsertTime;
}
?>