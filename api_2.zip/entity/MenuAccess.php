<?php
class MenuAccessClass
{
    public $MenuId;
    public $MenuTitle;
    public $MenuIcon;
    public $GroupId;
    public $MenuAccessId;
    public $MenuRef;
}
?>