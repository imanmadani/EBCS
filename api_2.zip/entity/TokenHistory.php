<?php
class TokenHistory
{
    public $Id;
    public $TokenId;
    public $Controller;
    public $Method;
    public $InsertTime;
}
?>